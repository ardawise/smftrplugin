This is a simple mode design to display the member's activity (from the Who's Online feature) and display in the user's profile page. If you have any questions or problems, please message me at the official SMF community as user: [url=http://www.simplemachines.org/community/index.php?action=profile;u=164151]Project Evolution[/url].

Created by Anthony Calandra/Project Evolution - 2010.