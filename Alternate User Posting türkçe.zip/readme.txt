[table]
[b]ByGold Taraf�ndan T�rk�ele�tirilmi�tir.[/b]
[td][b]Author:[/b] [url=https://www.simplemachines.org/community/index.php?action=profile;u=601387][b]ByGold[/b][/url][/td]
[/table]