*******************************
Contact Page
By: vbgamer45
https://www.smfhacks.com
*******************************

Mod Information: 
For SMF 2.1.x SMF 2.0.x and SMF 1.1.x and 1.0.x

Adds a contact page to the default theme for SMF.

Other mods can be found at SMFHacks.com
Include:
SMF Gallery
SMF Store
SMF Trader System
Newsletter Pro
SMF Store
SMF Classifieds
Downloads System
EzPortal
Ad Seller Pro



SMFHacks package server address is:
https://www.smfhacks.com
T�rk�ele�tirme ByGold