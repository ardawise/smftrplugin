<?php
/*
SMF Staff
Version 1.5
by:vbgamer45
http://www.smfhacks.com
*/

//Staff text strings
$txt['smfstaff_local'] = 'Moderatörler';
$txt['smfstaff_lastactive'] = 'Aktivite:';
$txt['smfstaff_forums'] = 'Forum:';
$txt['smfstaff_dateregistered'] = 'Kayıt Tarihi:';
$txt['smfstaff_contact'] = 'Destek:';
$txt['smfstaff_sendpm'] = 'PM Gönder';
$txt['smfstaff_avatar'] = 'Avatar';
$txt['smfstaff_options'] = 'Ayarlar';

$txt['smfstaff_nocatabove'] = 'Yukarıdaki Grup Hayır.';
$txt['smfstaff_nocatbelow'] = 'Yukarıdaki Grup Hayır.';
$txt['smfstaff_errgroupexists'] = 'Ekip Listesi.';

$txt['smfstaff_staffsetting'] = 'Ekip Sayfası Ayarlar';
$txt['smfstaff_showavatar'] = 'Avatarı Göster';
$txt['smfstaff_showlastactive'] = 'Aktiviteleri Göster';
$txt['smfstaff_showdateregistered'] = 'Kayıt Tarahini Göster';
$txt['smfstaff_showcontactinfo'] = 'Destek Sayfasını Göster';
$txt['smfstaff_showlocalmods'] = 'Moderatörleri Göster';

$txt['smfstaff_groupstoshow'] = 'Ekip Sayfasında Grupları Göster:';


$txt['smfstaff_groupstoadd'] = 'Ekip Sayfasına Grup Ekle:';

$txt['smfstaff_addgroup'] = 'Grup Ekle';
$txt['smfstaff_delgroup'] = 'Grup Sil';

$txt['smfstaff_up'] = 'Yukarı';
$txt['smfstaff_down'] = 'Aşağı';

$txt['smfstaff_savesettings'] = 'Ayarları Kaydet';
?>